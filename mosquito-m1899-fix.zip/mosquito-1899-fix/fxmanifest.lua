fx_version "cerulean"
game "rdr3"

rdr3_warning "I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships."


author "Mosquito"
description "Fix for inverted M1899 holstering."
lua54 'yes'


-- file 'weaponinfo_c.meta'
-- data_file 'WEAPONINFO_FILE_PATCH' 'weaponinfo_c.meta'

file 'weaponinfo_main.meta'
data_file 'WEAPONINFO_FILE_PATCH' 'weaponinfo_main.meta'

-- file 'weaponcomponents.meta'
-- data_file 'WEAPONCOMPONENTSINFO_FILE' 'weaponcomponents.meta'